<?php

session_start();

if(!isset($_SESSION['usuario'])){
  echo '
    <script>
    alert("Por favor debes iniciar sesion");
    window.location = "Login.php";
    </script>
  ';
  session_destroy();
  die();
}



?>




<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Usuarios</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="CSS/estilos.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
  </head>
  <body class="p-3 m-0 border-0 bd-example">
  
    <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
      <div class="container px-2px-lg-4">
        <a class="navbar-brand" href="#"><img src="IMG/NUEVO LOGO AM ANIVERSARIO 2.png"class="logo" alt="logoo" ></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link" href="#">/Inicio/</a>
            </li>
            <li class="nav-item">
              <a  href="#servicios" class="nav-link" >/Productos/</a>
            </li>
              <li class="nav-item">
                <a class="nav-link" href="#Conocenos" >/Conocenos/</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#Contacto" >/Contacto/</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="php/cerrar_sesion.php" >/Cerrar Sesión/</a>
              </li>
          </ul>
        </div>
      </div>
    </nav>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>

    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="IMG/diseñp.jpg" class="d-block w-100" height="700px">
        </div>
        <div class="carousel-item">
          <img src="IMG/diseño.jpg" class="d-block w-100" height="700px">
        </div>
        <div class="carousel-item">
          <img src="IMG/R.jpg" class="d-block w-100"  height="700px">
        </div>
      </div>
    </div>
    <center><Table class="table-primary">
      <tr>
        <td class="table-primary" > 
          <center><p>DISEÑOS Y PUBLICIDAD AM</p></center>
          <center><h5>Gracias por visitarnos, en la actualidad existen muchas imprentas y agencia de diseño grafico, pero nosotros tenemos algo que nos identifica como empresa, manejamos calidad de materiales, impresiones de alta calidad y con precios justos y accesibles.</h5></center>
        <center><h6>¡Conocenos!</h6></center>
        </td>
      </tr>
    </Table></center>

    <div class="row row-cols-1 row-cols-md-2 g-4">
      <div class="col">
        <div class="card">
          <img src="IMG/Grabado-laser.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Laser</h5>
            <p class="card-text">Grabado laser en acrilicos, termos, MDF por mencionar algunos</p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card">
          <img src="IMG/vinil.jpg" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Tipo de vinil</h5>
            <p class="card-text">Existen varios tipos de vinil: Transparente, blanco, microperforado, por mencionar algunos</p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card">
          <img src="IMG/impresion.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Impresiones</h5>
            <p class="card-text">Existe la impresion digital, gran formato y el Offset</p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card">
          <img src="IMG/PaletaColores_DiseñoGrafico2.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Colores</h5>
            <p class="card-text">En el diseño grafico existen los colores CMYK que son para impresion Y RGB que son para digital</p>
          </div>
        </div>
      </div>
    </div>


    <CENTER> <h2  class="text-primary" id="servicios">Productos</h2> </CENTER>
    <div class="row row-cols-1 row-cols-md-2 g-4">
      <div class="col">
        <div class="card">
          <img src="IMG/1 am.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Lonas</h5>
            <p class="card-text">Lona impresa, para publicidad</p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card">
          <img src="IMG/6AM.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Tarjeta</h5>
            <p class="card-text">Tarjeta de presentación con barniz</p>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card">
          <img src="IMG/3tablo.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Tabloides</h5>
            <p class="card-text">Impresiones para tajetas, libretas, volantes, ect.</p>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card">
          <img src="IMG/4laser.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Grabado laser</h5>
            <p class="card-text">Grabado laser y corte laser</p>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card">
          <img src="IMG/5et.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Etiquetas</h5>
            <p class="card-text">Etiquetas para bolsas,botellones, ect.</p>
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card">
          <img src="IMG/2vinil.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Vinil</h5>
            <p class="card-text">Impresiones en vinil, rotulaciones, ect.</p>
          </div>
        </div>
      </div>

    </div>
    <button class="btn btn-primary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasScrolling" aria-controls="offcanvasScrolling">MÁS INFORMACIÓN</button>

    <div class="offcanvas offcanvas-start" data-bs-scroll="true" data-bs-backdrop="false" tabindex="-1" id="offcanvasScrolling" aria-labelledby="offcanvasScrollingLabel">
      <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="offcanvasScrollingLabel">Acerca de nuestros servicios</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body">
        <p>TODO TIPO DE TRABAJO QUE SE REALIZA CUENTA CON GARANTIA, SIEMPRE Y CUANDO EL ERROR SEA DE NUESTRO PERSONAL Y/O POR ALGUN DAÑO MOSTRADO POR EL CLIENTE</p>
      </div>
      <p>
        <button class="btn btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapseWidthExample" aria-expanded="false" aria-controls="collapseWidthExample">
          Más Servicios
        </button>
      </p>
      <div style="min-height: 120px;">
        <div class="collapse collapse-horizontal" id="collapseWidthExample">
          <div class="card card-body" style="width: 300px;">
            Grabado laser, imanes, folio, seleccion, barniz, calendarios, gorras, playeras, grabado de yetis, etiquetas.
          </div>
        </div>
      </div>
    </div>
    <CENTER> <h2   class="text-primary" id="Conocenos">CONOCENOS</h2> </CENTER>

    <div class="jumbotron text-center">
      <h1>Diseños Y Publicidad AM</h1>
      <p>Conoce un poco más de nosotrós</p> 
    </div>
      
    <div class="container">
      <div class="row">
        <div class="col-sm-4">
          <CENTER><h3>¿Cuando se fundo Diseños y Publicidad AM?</h3></CENTER>
          <CENTER><p><strong>Se fundo en el año 2020</strong> Por Alejandro Martin, joven de 17 años en ese año, donde el amor que le tenia al trabajo, lo llevo a crear una pequeña empresa. Con mucho sacrificio y trabajo hoy por hoy, Diseños y Publicidad AM sigue creciendo</p>
        </div></CENTER>
        <div class="col-sm-4">
          <CENTER><h3>¿Quines somos?</h3></CENTER>
          <CENTER><p><strong>Somos una empresa</strong> que nos dedicamos a las impresiones para todo tipo de publicidad, ya sea digital o impresos. Llevamos un 3 años en el mercado, trabajamos a empresas reconocidas teniendo mas experiencia</p>
        </div></CENTER>
        <div class="col-sm-4">
          <CENTER><h3>Valores</h3></CENTER>
          <CENTER><p><strong>Nuestros Valore son:</strong> Son el respeto, igualdad, tolerancia, amabilidad  </p>
      </div></CENTER>

      <div class="card-group">
        <div class="card bg-warning">
          <div class="card-body text-center">
            <p style="color: rgb(0, 0, 0);" class="card-text"><strong> DISEÑOS </strong></p>
          </div>
        </div>
        <div class="card bg-danger">
          <div class="card-body text-center">
            <p style="color: rgb(0, 0, 0);" class="card-text"><strong> Y </strong></p>
          </div>
        </div>
        <div class="card bg-warning">
          <div class="card-body text-center">
            <p style="color: rgb(0, 0, 0);" class="card-text"><strong> PUBLICIDAD </strong></p>
          </div>
        </div>
        <div class="card bg-danger">
          <div class="card-body text-center">
            <p style="color: rgb(0, 0, 0);" class="card-text"><strong> AM </strong></p>
          </div>
        </div>
      </div>


      <div class="container mt-3">
        <img src="IMG/NUEVO LOGO AM ANIVERSARIO 2.png" class="float-start" alt="Paris" width="304" height="236"> 
        <img src="IMG/Pro.png" class="float-end" alt="Paris" width="304" height="236"> 
      </div>
    </div>
    
    
    <div class="container-fluid p-5 bg-warning text-white text-center">
      <h1 class="text-primary" id="Contacto">COTACTO<i class="fas fa-user"></i></h1>
      <p style="color: crimson;">Siguenos en todas nuestras redes sociales</p> 
    </div>
      
    <div class="container">
      <div class="row">
        <div class="col-sm-4">
          <h3>Facebook</h3>
          <p>Diseños y Publicidad AM</p>
          <h3>Instagram</h3>
          <p>Design_y_publicidad_am</p>
        </div>
        <div class="col-sm-4">
          <h3>WhatsApp</h3>
          <p>9993894591</p>
          <h3>Telefono</h3>
          <p>9993894591</p>
        </div>
        <div class="col-sm-4">
          <h3>Email</h3>        
          <p>alejandromartin1800@gmail.com</p>
          <h3>Dirección </h3>
          <p>Calle 66 x 11 y 65, colonia Amapola, Merida Yucatán</p>
        </div>
        <div class="container mt-3">
          <CENTER><img src="IMG/Pro.png" class="float-Center" alt="Paris" width="304" height="236"> </CENTER>
      </div>
      </div>
    <div class="container">
      <div class="spinner-border text-muted"></div>
      <div class="spinner-border text-primary"></div>
      <div class="spinner-border text-success"></div>
      <div class="spinner-border text-info"></div>
      <div class="spinner-border text-warning"></div>
      <div class="spinner-border text-danger"></div>
      <div class="spinner-border text-secondary"></div>
      <div class="spinner-border text-dark"></div>
      <div class="spinner-border text-light"></div>
    </div>
    <a class="nav-link" href="php/cerrar_sesion.php" >Cerrar Sesión</a>
  </body>
</html>

