<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Publico</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
    <link rel="stylesheet" href="CSS/estilos_index1.css">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic" rel="stylesheet" type="text/css" />
  </head>
  <body class="p-3 m-0 border-0 bd-example">
  
    <nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" style="background-color: #6BC1FF;" id="mainNav">
      <div class="container px-2px-lg-4">
        <a class="navbar-brand" href="#"><img src="IMG/NUEVO LOGO AM ANIVERSARIO 2.png"class="logo" alt="logoo" ></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link" href="Login.php"><strong> Inicio</strong></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="Login.php"><strong> Productos</strong></a>
            </li>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="Login.php" ><strong> Iniciar sesion </strong></a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
 
    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="IMG/diseñp.jpg" class="d-block w-100" height="500px">
        </div>
        <div class="carousel-item">
          <img src="IMG/diseño.jpg" class="d-block w-100" height="500px">
        </div>
        <div class="carousel-item">
          <img src="IMG/R.jpg" class="d-block w-100"  height="500px">
        </div>
        <div class="carousel-item">
          <img src="IMG/Grabado-laser.jpg" class="d-block w-100"  height="700px">
        </div>
      </div>
     <div class="container mt-3">
     <div class="mt-4 p-5 bg-primary text-white rounded">
        <center><h1>DISEÑOS Y PUBLICIDAD AM</h1></center>
        <center><h4>Gracias por visitarnos, en la actualidad existen muchas imprentas y agencia de diseño grafico, pero nosotros tenemos algo que nos identifica como empresa, manejamos calidad de materiales, impresiones de alta calidad y con precios justos y accesibles.</h4></center>
        <center><h2>¡Conocenos más, registrate! <a class="nav-link" href="Login.php" ><strong> Iniciar sesion </strong></a></h2></center> 
  </div>

  <div>
   <CENTER> <h2  class="text-primary" id="servicios"></h2> </CENTER>
    <div class="row row-cols-1 row-cols-md-2 g-4">
      <div class="col">
        <div class="card">
          <img src="IMG/1 am.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Lonas</h5>
            <p class="card-text">Lona impresa, para publicidad</p>
          </div>
        </div>
      </div>
      <div class="col">
        <div class="card">
          <img src="IMG/6AM.png" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title">Tarjeta</h5>
            <p class="card-text">Tarjeta de presentación con barniz</p>
          </div>
        </div>
      </div>
      <div class="container mt-3">
          <CENTER><img src="IMG/Pro.png" class="float-Center" alt="Paris" width="304" height="236"> </CENTER>
      </div>
      </div>
      <div class="container p-3 my-3 bg-primary text-white">
      <CENTER><h1>Advertencia</h1></CENTER>
      <CENTER><p>Para seguir navegando, registrate dandole click al boton <strong><a class="nav-link" href="Login.php" ><strong> Iniciar sesion </strong></a></strong></p></CENTER>
</div>

  </body> 
</html>

