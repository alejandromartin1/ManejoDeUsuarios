<?php

$conexion = mysqli_connect("localhost","root", "","login_register_db");

/*
if($conexion){
    echo 'Conectado exitosamente';
}else{
    echo 'No se ha podido conectar';
}
*/



?>